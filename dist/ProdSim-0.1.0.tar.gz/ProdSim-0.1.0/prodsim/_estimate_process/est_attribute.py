def source1(env, factory):
    yield env.timeout(1)
    yield 1
